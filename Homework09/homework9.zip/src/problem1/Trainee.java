package problem1;

public class Trainee extends StaffMember{

	/**
	 * 
	 * @param name
	 * @param surname
	 * @param phone
	 */
	public Trainee(String name, String surname, String phone) {
		super(name, surname, phone);
		
	}
	
}
