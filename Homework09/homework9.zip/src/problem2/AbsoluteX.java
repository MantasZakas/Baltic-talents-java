package problem2;

public class AbsoluteX extends DrawGraphics{

	public double getValueForY(double x) {
		return Math.abs(x);
	}
	
}
