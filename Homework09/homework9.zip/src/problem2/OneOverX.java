package problem2;

public class OneOverX extends DrawGraphics{

	public double getValueForY(double x) {
		return 1.0 / x;
	}
	
}
