package problem2;

public class SinX extends DrawGraphics{

	public double getValueForY(double x) {
		return Math.sin(x);
	}
	
}
