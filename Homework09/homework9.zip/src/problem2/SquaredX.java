package problem2;

public class SquaredX extends DrawGraphics{

	public double getValueForY(double x) {
		return Math.pow(x, 2);
	}
	
}
