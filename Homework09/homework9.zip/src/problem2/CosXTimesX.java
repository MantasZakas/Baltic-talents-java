package problem2;

public class CosXTimesX extends DrawGraphics{

	public double getValueForY(double x) {
		return Math.cos(x) * x;
	}
	
}
