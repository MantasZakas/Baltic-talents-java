package problem2;

public class CubedX extends DrawGraphics{
	
	public double getValueForY(double x) {
		return Math.pow(x, 3);
	}

}
