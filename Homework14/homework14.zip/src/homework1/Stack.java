package homework1;

public class Stack<T> {

	Item<T> p = null;

	public void push(T data) {
		Item<T> newItem = new Item<T>(data);
		if (p == null)
			p = newItem;
		else {
			newItem.next = p;
			p = newItem;
		}
	}

	public Item<T> pop() {
		if (p == null)
			return null;
		Item<T> tmp = p;
		p = p.next;
		return tmp;
	}

	public void remove(int index) {
		if (index == 0) {
			p = p.next;
			return;
		} else {
			Item<T> item = p;
			for (int i = 0; i < index - 1; i++) {
				if (item == null) return;
				item = item.next;
			}
			item.next = item.next.next;
		}
	}
	
	public void add(int index, T data) {
		Item<T> newItem = new Item<T>(data);
		Item<T> tmp = p;
		if (index == 0) {
			newItem.next = p;
			p = newItem;
			return;
		}
		for (int i = 0; i < index - 1; i++) {
			if (tmp.next == null) return;
			tmp = tmp.next;
		}
		newItem.next = tmp.next;
		tmp.next = newItem;
	}

	public String toString() {
		String output = "";
		Item<T> tmp = p;
		while (tmp != null) {
			output += tmp.data + " ";
			tmp = tmp.next;
		}
		return output;
	}

	public class Item<T> {

		public T data;
		public Item<T> next = null;

		public Item(T data) {
			this.data = data;
		}

	}

}
